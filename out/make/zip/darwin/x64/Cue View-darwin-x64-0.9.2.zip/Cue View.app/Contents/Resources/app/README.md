# Cue View
Monitor audio, video, and lighting equipment


## Supported Devices
- QLab 4
- ETC Eos Consoles
- Watchout
- PJLink Projectors
- X32 Audio Consoles
- XAir Audio Consoles


## ToDo
- Spikemark
- ATEM Video Mixers
- Art-Net, sACN Universes
- Epson Pro series Projectors
