# Cue View
A dashboard for everything in your show.

![Screen Shot 2021-10-26 at 11 57 21 PM](https://user-images.githubusercontent.com/919746/138997636-dfca293a-7c98-459d-85a3-405c9b11ce8a.png)




### Features
- Tons of supported equipment
- Auto discover devices on the network
- Live updating
- Configurable layout


## Supported Devices
- QLab 4
- ETC Eos Consoles
- Watchout
- PJLink Projectors
- X32 Audio Consoles
- XAir Audio Consoles


### Future Devices
- Spikemark
- ATEM Video Mixers
- Art-Net, sACN Universes
- Epson Pro series Projectors
- DiGiCo Consoles
- d&b DS100, amps

